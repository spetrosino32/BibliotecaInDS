var searchData=
[
  ['utente_0',['Utente',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_utente.html#a5ebb02ef99e0bd805fa7205818f9f393',1,'com::mycompany::bibliotecainds::model::Utente']]]
];
