var searchData=
[
  ['incrementacopie_0',['incrementaCopie',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_libro.html#aca41b8f1712337dae471ee939002a5c7',1,'com::mycompany::bibliotecainds::model::Libro']]],
  ['initialize_1',['initialize',['../classcom_1_1mycompany_1_1bibliotecainds_1_1controller_1_1_biblioteca_controller.html#adc63f4ba7700b39f54dbddd53d634cc0',1,'com::mycompany::bibliotecainds::controller::BibliotecaController']]],
  ['isscaduto_2',['isScaduto',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_prestito.html#a07f4004219667a409904f7d883e04fa6',1,'com::mycompany::bibliotecainds::model::Prestito']]]
];
