var searchData=
[
  ['utente_2ejava_0',['Utente.java',['../_utente_8java.html',1,'']]],
  ['utenteservice_2ejava_1',['UtenteService.java',['../_utente_service_8java.html',1,'']]],
  ['utenteserviceimpl_2ejava_2',['UtenteServiceImpl.java',['../_utente_service_impl_8java.html',1,'']]]
];
