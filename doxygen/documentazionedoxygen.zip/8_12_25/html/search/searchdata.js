var indexSectionsWithContent =
{
  0: "abcdgilmprsu",
  1: "abclpsu",
  2: "c",
  3: "abclmprsu",
  4: "acdgilmprsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions"
};

