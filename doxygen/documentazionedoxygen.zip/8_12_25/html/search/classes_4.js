var searchData=
[
  ['personale_0',['Personale',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_personale.html',1,'com::mycompany::bibliotecainds::model']]],
  ['prestito_1',['Prestito',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_prestito.html',1,'com::mycompany::bibliotecainds::model']]],
  ['prestitoservice_2',['PrestitoService',['../interfacecom_1_1mycompany_1_1bibliotecainds_1_1service_1_1_prestito_service.html',1,'com::mycompany::bibliotecainds::service']]],
  ['prestitoserviceimpl_3',['PrestitoServiceImpl',['../classcom_1_1mycompany_1_1bibliotecainds_1_1service_1_1_prestito_service_impl.html',1,'com::mycompany::bibliotecainds::service']]]
];
