var searchData=
[
  ['salva_0',['salva',['../classcom_1_1mycompany_1_1bibliotecainds_1_1data_1_1_archivio.html#a21f413cf0a7254a71e037fcb9e0c89c6',1,'com::mycompany::bibliotecainds::data::Archivio']]],
  ['secondarycontroller_1',['SecondaryController',['../classcom_1_1mycompany_1_1bibliotecainds_1_1controller_1_1_secondary_controller.html',1,'com::mycompany::bibliotecainds::controller']]],
  ['secondarycontroller_2ejava_2',['SecondaryController.java',['../_secondary_controller_8java.html',1,'']]],
  ['setroot_3',['setRoot',['../classcom_1_1mycompany_1_1bibliotecainds_1_1_app.html#a5984302de55d4df09b9bef4a51383cac',1,'com::mycompany::bibliotecainds::App']]],
  ['start_4',['start',['../classcom_1_1mycompany_1_1bibliotecainds_1_1_app.html#a00fa4013bfb9ab8600b535b84be0718a',1,'com::mycompany::bibliotecainds::App']]]
];
