var searchData=
[
  ['personale_0',['Personale',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_personale.html#ab4f783d9aedeef4bf5b9f02494f434b4',1,'com::mycompany::bibliotecainds::model::Personale']]],
  ['prestito_1',['Prestito',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_prestito.html#a15af9a316b19f17cebbf736a1fed1d10',1,'com::mycompany::bibliotecainds::model::Prestito']]]
];
