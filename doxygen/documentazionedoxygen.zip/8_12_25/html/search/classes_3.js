var searchData=
[
  ['libro_0',['Libro',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_libro.html',1,'com::mycompany::bibliotecainds::model']]],
  ['logincontroller_1',['LoginController',['../classcom_1_1mycompany_1_1bibliotecainds_1_1controller_1_1_login_controller.html',1,'com::mycompany::bibliotecainds::controller']]]
];
