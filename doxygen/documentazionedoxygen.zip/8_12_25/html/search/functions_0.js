var searchData=
[
  ['aggiungilibro_0',['aggiungiLibro',['../interfacecom_1_1mycompany_1_1bibliotecainds_1_1service_1_1_catalogo_service.html#a4d23edc092ddd891b4c0eddc4adeef14',1,'com.mycompany.bibliotecainds.service.CatalogoService.aggiungiLibro()'],['../classcom_1_1mycompany_1_1bibliotecainds_1_1service_1_1_catalogo_service_impl.html#ae9f85228131bc9a6e9f570a4f06be2a5',1,'com.mycompany.bibliotecainds.service.CatalogoServiceImpl.aggiungiLibro()']]],
  ['aggiungiprestito_1',['aggiungiPrestito',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_utente.html#aa3810b3a9ed1ad2cc03e560a8649c8d4',1,'com::mycompany::bibliotecainds::model::Utente']]]
];
