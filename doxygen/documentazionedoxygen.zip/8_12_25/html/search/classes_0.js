var searchData=
[
  ['app_0',['App',['../classcom_1_1mycompany_1_1bibliotecainds_1_1_app.html',1,'com::mycompany::bibliotecainds']]],
  ['archivio_1',['Archivio',['../classcom_1_1mycompany_1_1bibliotecainds_1_1data_1_1_archivio.html',1,'com::mycompany::bibliotecainds::data']]]
];
