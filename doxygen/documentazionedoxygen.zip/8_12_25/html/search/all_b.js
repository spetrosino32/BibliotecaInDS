var searchData=
[
  ['utente_0',['Utente',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_utente.html',1,'com.mycompany.bibliotecainds.model.Utente'],['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_utente.html#a5ebb02ef99e0bd805fa7205818f9f393',1,'com.mycompany.bibliotecainds.model.Utente.Utente()']]],
  ['utente_2ejava_1',['Utente.java',['../_utente_8java.html',1,'']]],
  ['utenteservice_2',['UtenteService',['../interfacecom_1_1mycompany_1_1bibliotecainds_1_1service_1_1_utente_service.html',1,'com::mycompany::bibliotecainds::service']]],
  ['utenteservice_2ejava_3',['UtenteService.java',['../_utente_service_8java.html',1,'']]],
  ['utenteserviceimpl_4',['UtenteServiceImpl',['../classcom_1_1mycompany_1_1bibliotecainds_1_1service_1_1_utente_service_impl.html',1,'com::mycompany::bibliotecainds::service']]],
  ['utenteserviceimpl_2ejava_5',['UtenteServiceImpl.java',['../_utente_service_impl_8java.html',1,'']]]
];
