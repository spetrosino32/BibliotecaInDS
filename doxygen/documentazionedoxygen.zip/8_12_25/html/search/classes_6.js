var searchData=
[
  ['utente_0',['Utente',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_utente.html',1,'com::mycompany::bibliotecainds::model']]],
  ['utenteservice_1',['UtenteService',['../interfacecom_1_1mycompany_1_1bibliotecainds_1_1service_1_1_utente_service.html',1,'com::mycompany::bibliotecainds::service']]],
  ['utenteserviceimpl_2',['UtenteServiceImpl',['../classcom_1_1mycompany_1_1bibliotecainds_1_1service_1_1_utente_service_impl.html',1,'com::mycompany::bibliotecainds::service']]]
];
