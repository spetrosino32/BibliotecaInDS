var searchData=
[
  ['main_0',['main',['../classcom_1_1mycompany_1_1bibliotecainds_1_1_app.html#a4c5544b255925eb82114fe161d54d588',1,'com::mycompany::bibliotecainds::App']]],
  ['modificacatalogo_1',['modificaCatalogo',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_personale.html#a37d11e30a6872aa478686b8f24342901',1,'com::mycompany::bibliotecainds::model::Personale']]]
];
