var searchData=
[
  ['libro_0',['Libro',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_libro.html#a145b77d72de27208d15eed3918bd2dd3',1,'com::mycompany::bibliotecainds::model::Libro']]]
];
