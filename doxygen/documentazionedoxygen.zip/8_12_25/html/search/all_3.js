var searchData=
[
  ['decrementacopie_0',['decrementaCopie',['../classcom_1_1mycompany_1_1bibliotecainds_1_1model_1_1_libro.html#a0963b8727d2aea8e510e3ee1f323a935',1,'com::mycompany::bibliotecainds::model::Libro']]]
];
